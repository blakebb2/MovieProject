package movieRecords;

import java.util.HashMap;

public class QueryS {

	public void main(HashMap<Integer, FullMovieBase> movieCollection) {
		// TODO Auto-generated method stub

	}

}
