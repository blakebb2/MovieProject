package movieRecords;

import java.util.HashMap;

public class QueryM {

	public void main(HashMap<Integer, FullMovieBase> movieCollection) {
		// TODO Auto-generated method stub

	}

}
