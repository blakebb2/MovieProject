package movieRecords;

public class FullMovieBase {

	private int boxOffice;
	private int imdbRating;
	private String title;
	private String Director;
	private String Cast1;
	private String Cast2;	
	private String Cast3;	
	private String Cast4;
	private String Cast5;
	
	public class Movie {

	}

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public int getBoxOffice() {
		return boxOffice;
	}
	public void setBoxOffice(int boxOffice) {
		this.boxOffice = boxOffice;
	}
	public int getImdbRating() {
		return imdbRating;
	}
	public void setImdbRating(int imdbRating) {
		this.imdbRating = imdbRating;
	}
	public String getDirector() {
		return Director;
	}
	public void setDirector(String director) {
		Director = director;
	}
	public String getCast1() {
		return Cast1;
	}
	public void setCast1(String cast1) {
		Cast1 = cast1;
	}
	public String getCast2() {
		return Cast2;
	}
	public void setCast2(String cast2) {
		Cast2 = cast2;
	}
	public String getCast3() {
		return Cast3;
	}
	public void setCast3(String cast3) {
		Cast3 = cast3;
	}
	public String getCast4() {
		return Cast4;
	}
	public void setCast4(String cast4) {
		Cast4 = cast4;
	}
	public String getCast5() {
		return Cast5;
	}
	public void setCast5(String cast5) {
		Cast5 = cast5;
	}


}
