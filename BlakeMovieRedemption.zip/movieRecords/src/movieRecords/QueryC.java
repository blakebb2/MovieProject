package movieRecords;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

public class QueryC {

	public void main(HashMap<Integer, FullMovieBase> movieCollection) {
//		Collection<FullMovieBase> c = movieCollection.values();
//        List<String> l = new ArrayList<>(c);
//
//        Set<String> set = new HashSet<>(c);
//        Iterator<String> i = set.iterator();
//        String valueMax = "";
//        int max = 0;
//        while(i.hasNext()){
//            String s = i.next();
//            int frequence = Collections.frequency(l, s);
//            if(frequence > max){
//                max = frequence;
//                valueMax = s;
//            }
//        }
//
//        System.out.println(valueMax+": "+max);
	}

}
