package movieRecords;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.Scanner;

import org.junit.Test;

public class main {

	 public static void main(String[] args) {
		DataBuilder test = new DataBuilder();
		test.fileBuilder();
	}

	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
		@Test
		public void TestE() {
			DataBuilder test = new DataBuilder();
			test.fileBuilder();
			Class<Scanner> sc = Scanner.class;
			
		}
		
		@Test
		public void TestD() {
			DataBuilder test = new DataBuilder();
			test.fileBuilder();
		}
		 
		@Test
		public void TestC() {
			DataBuilder test = new DataBuilder();
			test.fileBuilder();
		}
		 
		
		@Test
		public void TestS() {
			DataBuilder test = new DataBuilder();
			test.fileBuilder();
		}
		 
		
		@Test
		public void TestM() {
			DataBuilder test = new DataBuilder();
			test.fileBuilder();
		}
		 
}
